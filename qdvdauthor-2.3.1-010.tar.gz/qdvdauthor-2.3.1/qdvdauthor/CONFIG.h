#ifndef CONFIG_H
#define CONFIG_H
#define PREFIX_DIRECTORY "/usr"
#define SYSTEM_DIRECTORY "/usr"
#endif // CONFIG_H
